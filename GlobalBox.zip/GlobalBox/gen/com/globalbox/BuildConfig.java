/** Automatically generated file. DO NOT MODIFY */
package com.globalbox;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}