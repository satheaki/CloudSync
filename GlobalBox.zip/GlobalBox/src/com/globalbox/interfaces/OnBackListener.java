/**
 * 
 */
package com.globalbox.interfaces;

/**
 * @author darshanbidkar
 *
 */
public interface OnBackListener {
	public void onBackPressed();
}
