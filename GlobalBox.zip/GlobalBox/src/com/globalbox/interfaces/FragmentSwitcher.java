/**
 * 
 */
package com.globalbox.interfaces;

/**
 * @author darshanbidkar
 *
 */
public interface FragmentSwitcher {
public void switchToFilesFragment();
}
