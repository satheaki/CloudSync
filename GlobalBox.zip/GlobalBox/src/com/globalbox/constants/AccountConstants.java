/**
 * 
 */
package com.globalbox.constants;

/**
 * @author darshanbidkar
 *
 */
public class AccountConstants {

	/**
	 * 
	 */
	private AccountConstants() {
		// TODO Auto-generated constructor stub
	}

	public static final int DROPBOX = 1;
	public static final int ONEDRIVE = 2;
	public static final int GOOGLE_DRIVE = 3;

}
