/**
 * 
 */
package com.globalbox.constants;

import com.dropbox.client2.session.Session.AccessType;

/**
 * @author darshanbidkar
 *
 */
public class DropboxConstants {

	/**
	 * 
	 */
	private DropboxConstants() {
		// TODO Auto-generated constructor stub
	}

	public final static String APP_KEY = "k158duqi1da4o4u";
	public final static String APP_SECRET_KEY = "4np074q82sohxe9";
	public final static AccessType ACCESS_TYPE = AccessType.DROPBOX;
	public final static String ACCESS_TOKEN = "access_token";

}
