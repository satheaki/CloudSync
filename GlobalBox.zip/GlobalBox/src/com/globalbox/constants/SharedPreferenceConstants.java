/**
 * 
 */
package com.globalbox.constants;

/**
 * @author darshanbidkar
 *
 */
public class SharedPreferenceConstants {

	/**
	 * 
	 */
	private SharedPreferenceConstants() {
	}

	public static final String FILE_NAME = "globalbox_data";

}
